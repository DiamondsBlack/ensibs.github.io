
            function AffichageTexte() {
                document.getElementById("myfooterJS").innerHTML =
                "L'ENSIBS devient la 5e école associée au réseau Polytech!";
            }
